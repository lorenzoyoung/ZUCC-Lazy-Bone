//page/order/order.js
var sliderWidth = 96; // 需要设置slider的宽度，用于计算中间位置

Page({
  data: {
    tabs: ["快递代拿", "快递代寄", "餐饮代买"],
    activeIndex: 1,
    sliderOffset: 0,
    sliderLeft: 0,
    array: ['一食堂后面快递点', '宜博电竞馆中通点', 'cc网咖圆通点', '北校南门天猫点'],
    objectArray: [
      {
        id: 0,
        name: '一食堂后面快递点'
      },
      {
        id: 1,
        name: '宜博电竞馆中通点'
      },
      {
        id: 2,
        name: 'cc网咖圆通点'
      },
      {
        id: 3,
        name: '北校南门天猫点'
      }
    ]
  },
  onLoad: function () {
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          sliderLeft: (res.windowWidth / that.data.tabs.length - sliderWidth) / 2,
          sliderOffset: res.windowWidth / that.data.tabs.length * that.data.activeIndex
        });
      }
    });
  },
  tabClick: function (e) {
    this.setData({
      sliderOffset: e.currentTarget.offsetLeft,
      activeIndex: e.currentTarget.id
    });
  },
  //选择以后变更显示值
  bindPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index: e.detail.value
    })
  },
  // 确定按钮绑定事件
  showTopTips: function () {
    var that = this;
    this.setData({
      showTopTips: true
    });
    setTimeout(function () {
      that.setData({
        showTopTips: false
      });
    }, 3000);
  }
});